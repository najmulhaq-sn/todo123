<?php echo e($data); ?>

<?php /**PATH /Users/baseem/Desktop/todo/todo/resources/views/data.blade.php ENDPATH**/ ?>